<!-- Footer Section Starts -->
<div class="footer">
            <div class="wrapper">
                <p class="text-center">2022 All rights reserved, Food House. Developed By - <a href="#"> PBL/DBMS GROUP 13</a></p>
            </div>
        </div>
        <!-- Footer Section Ends -->

    </body>
</html>